import { auth } from "@clerk/nextjs/server";
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const db = prisma as any;

// GET /api/os/[id]/miner-checks
export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const { userId } = await auth();
  if (!userId) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

  const checks = await db..findMany({
    where: { osId: params.id },
    include: {
      minerInstance: {
        select: { id: true, serialNumber: true, containerId: true, status: true },
      },
    },
    orderBy: [{ minerInstance: { containerId: "asc" } }, { minerInstance: { serialNumber: "asc" } }],
  });

  return NextResponse.json({ checks });
}

// PUT /api/os/[id]/miner-checks — upsert array of checks
export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const { userId } = await auth();
  if (!userId) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

  const usuario = await db.usuario.findUnique({ where: { clerkId: userId } });
  if (!usuario || !["ADMIN", "SUPERVISOR", "TECNICO"].includes(usuario.cargo)) {
    return NextResponse.json({ error: "Sem permissão" }, { status: 403 });
  }

  const body = await req.json();
  const schema = z.array(z.object({
    minerInstanceId: z.string(),
    status:          z.enum(["FUNCIONANDO", "OFFLINE", "COM_FALHA"]),
    observacao:      z.string().optional().nullable(),
  })).min(1).max(500);

  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Dados inválidos" }, { status: 400 });

  await Promise.all(
    parsed.data.map((row) =>
      db.minerCheckOS.upsert({
        where: { osId_minerInstanceId: { osId: params.id, minerInstanceId: row.minerInstanceId } },
        update: {
          status:          row.status,
          observacao:      row.observacao ?? null,
          atualizadoPorId: usuario.id,
          atualizadoEm:    new Date(),
        },
        create: {
          osId:            params.id,
          minerInstanceId: row.minerInstanceId,
          status:          row.status,
          observacao:      row.observacao ?? null,
          atualizadoPorId: usuario.id,
          atualizadoEm:    new Date(),
        },
      })
    )
  );

  return NextResponse.json({ ok: true });
}